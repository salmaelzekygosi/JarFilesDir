package com.gosi.kafka.producer;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import java.util.Properties;

public class KafkaOAuthApplication {
    public static void main(String[] args) {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "your-broker.domain.com:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

        props.put("security.protocol", "SASL_SSL");
        props.put("sasl.mechanism", "OAUTHBEARER");
        
        props.put("sasl.login.callback.handler.class", "com.gosi.kafka.auth.PasswordGrantCallbackHandler");

        String jaasConfig = "org.apache.kafka.common.security.oauthbearer.OAuthBearerLoginModule required " +
                "tokenUrl=\"https://identitydev.gosi.gov.sa/am/oauth2/realms/root/realms/wiam/access_token\" " +
                "clientId=\"confluent-rbac\" " +
                "clientSecret=\"GOSIwiam@2025\" " +
                "username=\"jd026034\" " +
                "password=\"F73,tnq9@$3f2D-C\";";
        props.put("sasl.jaas.config", jaasConfig);

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            ProducerRecord<String, String> record = new ProducerRecord<>("target-topic", "key", "test-message");
            producer.send(record).get();
            System.out.println("Message successfully published using OAuth password grant.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
