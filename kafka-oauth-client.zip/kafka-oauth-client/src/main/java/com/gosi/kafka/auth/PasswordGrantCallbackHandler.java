package com.gosi.kafka.auth;

import org.apache.kafka.common.security.auth.AuthenticateCallbackHandler;
import org.apache.kafka.common.security.oauthbearer.OAuthBearerToken;
import org.apache.kafka.common.security.oauthbearer.OAuthBearerTokenCallback;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.AppConfigurationEntry;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

public class PasswordGrantCallbackHandler implements AuthenticateCallbackHandler {
    private String tokenUrl;
    private String clientId;
    private String clientSecret;
    private String username;
    private String password;
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    public void configure(Map<String, ?> configs, String saslMechanism, List<AppConfigurationEntry> jaasConfigEntries) {
        if (!jaasConfigEntries.isEmpty()) {
            Map<String, ?> options = jaasConfigEntries.get(0).getOptions();
            this.tokenUrl = (String) options.get("tokenUrl");
            this.clientId = (String) options.get("clientId");
            this.clientSecret = (String) options.get("clientSecret");
            this.username = (String) options.get("username");
            this.password = (String) options.get("password");
        }
    }

    @Override
    public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
        for (Callback callback : callbacks) {
            if (callback instanceof OAuthBearerTokenCallback) {
                OAuthBearerTokenCallback oauthCallback = (OAuthBearerTokenCallback) callback;
                try {
                    OAuthBearerToken token = fetchToken();
                    oauthCallback.token(token);
                } catch (Exception e) {
                    oauthCallback.error("token_fetch_error", "Failed to fetch OAuth token", e.getMessage());
                }
            } else {
                throw new UnsupportedCallbackException(callback);
            }
        }
    }

    private OAuthBearerToken fetchToken() throws Exception {
        String requestBody = String.format(
            "grant_type=password&client_id=%s&client_secret=%s&username=%s&password=%s",
            URLEncoder.encode(clientId, StandardCharsets.UTF_8),
            URLEncoder.encode(clientSecret, StandardCharsets.UTF_8),
            URLEncoder.encode(username, StandardCharsets.UTF_8),
            URLEncoder.encode(password, StandardCharsets.UTF_8)
        );

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(tokenUrl))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP " + response.statusCode() + ": " + response.body());
        }

        JsonNode jsonResponse = mapper.readTree(response.body());
        String accessToken = jsonResponse.get("access_token").asText();
        
        long expiresIn = jsonResponse.has("expires_in") ? jsonResponse.get("expires_in").asLong() : 3600;
        long lifetimeMs = System.currentTimeMillis() + (expiresIn * 1000);

        return new BasicOAuthBearerToken(accessToken, lifetimeMs, username);
    }

    @Override
    public void close() {}
}
