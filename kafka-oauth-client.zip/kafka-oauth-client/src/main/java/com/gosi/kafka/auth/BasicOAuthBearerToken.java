package com.gosi.kafka.auth;

import org.apache.kafka.common.security.oauthbearer.OAuthBearerToken;
import java.util.Set;

public class BasicOAuthBearerToken implements OAuthBearerToken {
    private final String token;
    private final long lifetimeMs;
    private final String principalName;
    private final long startTimeMs;

    public BasicOAuthBearerToken(String token, long lifetimeMs, String principalName) {
        this.token = token;
        this.lifetimeMs = lifetimeMs;
        this.principalName = principalName;
        this.startTimeMs = System.currentTimeMillis();
    }

    @Override
    public String value() { return token; }

    @Override
    public Set<String> scope() { return Set.of(); }

    @Override
    public long lifetimeMs() { return lifetimeMs; }

    @Override
    public String principalName() { return principalName; }

    @Override
    public Long startTimeMs() { return startTimeMs; }
}
