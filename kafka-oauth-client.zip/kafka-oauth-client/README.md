# Kafka OAuth Client - Password Grant

This is a standard Maven project that provides a custom `AuthenticateCallbackHandler` to authenticate a Kafka client using an OAuth Resource Owner Password Credentials (ROPC) grant.

## Structure
- `src/main/java/com/gosi/kafka/auth/`: Contains the custom Confluent/Kafka security implementations.
- `src/main/java/com/gosi/kafka/producer/`: Contains the Kafka producer application.

## Usage
1. Update the `BOOTSTRAP_SERVERS_CONFIG` in `KafkaOAuthApplication.java` to match your cluster.
2. Build the project: `mvn clean package`
3. Run the application to test the connection.
